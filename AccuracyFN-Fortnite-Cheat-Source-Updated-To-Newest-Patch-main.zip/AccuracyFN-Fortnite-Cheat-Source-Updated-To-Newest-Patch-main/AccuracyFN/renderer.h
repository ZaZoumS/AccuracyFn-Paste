#pragma once

namespace rend {
	BOOLEAN Initialize();

	static float width = 0;
	static float height = 0;
}